data(penguins)
view(penguins)
#forgot to save the code :(